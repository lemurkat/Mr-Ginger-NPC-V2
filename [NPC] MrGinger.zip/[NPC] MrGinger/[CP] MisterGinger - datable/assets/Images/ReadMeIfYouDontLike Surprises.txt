There's a lot of files in here, isn't there?
More than you might expect from a mod where the main character is a cat.
But that's just it: Mr. Ginger isnt't just a cat (unless you want him to be, in which case, check the config file, set it to "true" and avoid the conplications below).

At 14-hearts, the enchantment on Mr. Ginger will break and restore his original form.

You can see him by opening the 'MisterGinger2' files in here.

He tells the story of how he came to be a cat, and (if you wait until the next day and don't adjust the config as above) explains why he has chosen to live with Jas and co.

Mr. Ginger is intended to be the parental guardian that I feel is lacking from her life when Shane more-or-less favours the booze, and Marnie spends (almost) every evening at the pub or with Lewis. It felt wrong that a child would be left alone so often at night - especially one who clearly has some sort of trauma in her past.

Re: her parents death, in the canon game it is never indicated how they died, nor that they died together (although I suppose it is inferred). I understand some mods will go into greater depth, and this mod will likely contradict them. In my storyline, Jas's father "died" before she was born, her mother (Mona, who is buried in the graveyard) sometime when Jas was aged around 3-4 (to keep it inline with TenThouandCat's "Immersive Shane" mod). This stoyline is supported in my Jas expansion. 

If you do not feel comfortable having him around in his restored form (his dialogue gets decidedly more flirty, and I appreciate some players may have chosen to marry a cat because they want a cat, not a husband!), you can toggle the cat back whenever you choose. You can even switch between them if you like! (The dialogue will switch back too, he has full dialogue for both forms and a different story arc too). There's even a special cutscene (to hopefully restore immersion. You should watch it even if you do decide to config Tristan back - it's fun)! The cat returns every Monday and Friday when he ventures into the town. He'll explain why this is. Note that how you answer the question at the end of the 14-heart scene will NOT affect his form the next morning, you will need to change it manually (I did consider it, but it was more of a challenge to code, and wouldn't allow the player to freely switch back and forth).

If enough people play and enjoy Tristan (I have no idea how many ppl will choose to marry a cat, and how many will also be happy when that cat turns out to be a man), I may write some more cutscenes with him, including one where he and Shane meet up again, since they were, canonically and in Immersive Shane, friends.
